create procedure login(IN nae varchar(32), IN pwd varchar(32), OUT r int)
  BEGIN
		DECLARE sid int;
		DECLARE st int;
		select id from account where uname COLLATE utf8_unicode_ci = nae into sid;
		if(sid) then
				select state from account where uname COLLATE utf8_unicode_ci = nae and `password` = password(pwd) into st;
				if(st is not null) then
						if(st = 1) then 
								set r = 4;
						else 
								set r = 3;
						end if;
				else 
						set r = 2;
				end if;
		else
				set r = 1;
		end if;
END;

