create procedure po(IN i int)
  begin
select * from student where sid = i;
end;

